﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerateRandomizedArray
{
    internal class Program
    {
        
        public static int[] genarateUniqueRandomVals(int startingNumber, int lastNumber)
        {
            try
            {
                int[] randomizedArray = new int[lastNumber - startingNumber + 1];
                for (int i = 0; i < randomizedArray.Length; ++i)
                {
                    randomizedArray[i] = startingNumber + i;
                }
                Random random = new Random();

                for (int i = 0; i < randomizedArray.Length; ++i)
                {
                    int index = random.Next(randomizedArray.Length);
                    
                    if (i == index)
                        continue;
                   
                    int tmp = randomizedArray[i];

                    randomizedArray[i] = randomizedArray[index];
                    randomizedArray[index] = tmp;
                }

                return randomizedArray;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
           
        }
        static void Main(string[] args)
        {
            try
            {
                int startingNumber, lastNumber ;
                Console.WriteLine("Enter Starting Number : ");
                startingNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Ending Number :");
                lastNumber = Convert.ToInt32(Console.ReadLine());
                int[] finalRandomizedArray = genarateUniqueRandomVals(startingNumber, lastNumber);
                Console.WriteLine("Random unique values from " + startingNumber + " to " + lastNumber + ": ");
                foreach (int val in finalRandomizedArray)
                    Console.Write(val + " ");
                Console.ReadLine();
            }
            catch (Exception e) { 
            Console.WriteLine(e.Message);
                Console.ReadLine();
            }
           
        }
       
    }
}
